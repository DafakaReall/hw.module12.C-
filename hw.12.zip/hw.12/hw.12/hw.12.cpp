﻿#include <iostream>
#include <fstream>
#include <cstring>
#include <io.h>

int main()
{
    char path[260];
    char mask[100];
    char word[100];

    std::cout << "Enter path: ";
    std::cin.getline(path, 260);

    std::cout << "Enter file mask (for example *.txt): ";
    std::cin.getline(mask, 100);

    std::cout << "Enter word to search: ";
    std::cin.getline(word, 100);

    char searchPath[360];

    strcpy_s(searchPath, path);
    strcat_s(searchPath, "\\");
    strcat_s(searchPath, mask);

    _finddata_t fileInfo;

    intptr_t handle = _findfirst(searchPath, &fileInfo);

    if (handle == -1)
    {
        std::cout << "Files not found.\n";
        return 0;
    }

    do
    {
        if (!(fileInfo.attrib & _A_SUBDIR))
        {
            char filePath[360];

            strcpy_s(filePath, path);
            strcat_s(filePath, "\\");
            strcat_s(filePath, fileInfo.name);

            std::ifstream file(filePath);

            if (!file.is_open())
            {
                std::cout << "Cannot open: " << fileInfo.name << "\n";
                continue;
            }

            char line[1000];
            bool found = false;

            while (file.getline(line, 1000))
            {
                if (strstr(line, word) != nullptr)
                {
                    found = true;
                    break;
                }
            }

            file.close();

            if (found)
            {
                std::cout << "Word found in: " << fileInfo.name << "\n";
            }
        }

    } while (_findnext(handle, &fileInfo) == 0);

    _findclose(handle);

    return 0;
}
